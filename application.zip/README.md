# Forked from https://github.com/thatshaman/CharrioKart

# Super Charrio Kart
A basic 3D kart racing game styled after an old game with a somewhat similar name. Originally build in two weeks for the Guild Wars 2 community as an April Fool's joke. 

![Splash Screen](https://www.thatshaman.com/games/charrio/graphics/splash.jpg)

# Features
- Six exciting tracks!
- Four unique karts!
- Mobile, tablet and gamepad support
- Build with Vanilla JS, three.js and howler.js

# Demo
- [Play Charrio Kart online](https://www.thatshaman.com/games/charrio)

# Author

- [that_shaman](http://www.thatshaman.com)
